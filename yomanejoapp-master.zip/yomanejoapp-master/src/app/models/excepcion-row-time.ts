export interface ExcepcionRowTIme {
    hour_start: string;
    hour_finish: string;
    horariosDesde: Array<string>;
    horariosHasta: Array<string>;
    horariosTotales: Array<string>;
    dir_alt: boolean;
}
