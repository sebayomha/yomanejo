export interface GeneralHour {
    hour_start: string,
    hour_finish: string,
    address_alternative: boolean,
    from: Array<string>,
    to: Array<string>,
  }
  